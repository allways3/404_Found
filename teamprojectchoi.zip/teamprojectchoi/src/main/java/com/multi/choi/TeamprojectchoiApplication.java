package com.multi.choi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamprojectchoiApplication {

    public static void main(String[] args) {
        SpringApplication.run(TeamprojectchoiApplication.class, args);
    }

}
