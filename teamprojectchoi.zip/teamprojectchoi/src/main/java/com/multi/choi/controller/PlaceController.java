package com.multi.choi.controller;

import com.multi.choi.service.PlaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PlaceController {

    @Autowired
    private PlaceService placeService;

    @GetMapping("/places")
    public String getImages(Model model) {
        model.addAttribute("image1", placeService.getImageUrl(1));
        model.addAttribute("image2", placeService.getImageUrl(2));
        return "index";
    }
}