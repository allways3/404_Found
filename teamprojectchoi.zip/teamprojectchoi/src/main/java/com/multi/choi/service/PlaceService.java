package com.multi.choi.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;

@Service
public class PlaceService {

    @Value("${tour.api.key}")
    private String apiKey;

    @Value("${tour.api.url}")
    private String apiUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public String getImageUrl(int index) {
        try {
            String url = apiUrl + "/searchKeyword1?serviceKey=" + apiKey +
                    "&MobileOS=ETC&MobileApp=TestApp&keyword=경복궁&numOfRows=2&pageNo=1";
            String response = restTemplate.getForObject(url, String.class);

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(response)));
            doc.getDocumentElement().normalize();

            NodeList header = doc.getElementsByTagName("cmmMsgHeader");
            if (header.getLength() > 0) {
                NodeList errMsg = doc.getElementsByTagName("errMsg");
                if (errMsg.getLength() > 0 && "SERVICE ERROR".equals(errMsg.item(0).getTextContent())) {
                    System.err.println("API Error: " + doc.getElementsByTagName("returnAuthMsg").item(0).getTextContent());
                    return getFallbackImage(index);
                }
            }

            NodeList items = doc.getElementsByTagName("item");
            if (items.getLength() >= 2) {
                NodeList firstImages = ((org.w3c.dom.Element) items.item(index - 1)).getElementsByTagName("firstimage");
                if (firstImages.getLength() > 0) {
                    String imageUrl = firstImages.item(0).getTextContent();
                    return imageUrl.isEmpty() ? getFallbackImage(index) : imageUrl;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return getFallbackImage(index);
    }

    private String getFallbackImage(int index) {
        return index == 1 ?
                "https://via.placeholder.com/300?text=Image+1" :
                "https://via.placeholder.com/300?text=Image+2";
    }
}